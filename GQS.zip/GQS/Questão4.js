function inverterString(str) {
    return str.split("").reverse().join("");
}

console.log(inverterString("Araujo"));