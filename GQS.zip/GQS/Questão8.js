function ordenarArray(arr) {
    return arr.sort((a, b) => a - b);
}

console.log(ordenarArray([1998, 2001, 2002, 1999, 2000]));